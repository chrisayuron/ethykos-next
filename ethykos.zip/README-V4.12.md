# Éthykos Next V4.12 — invitaciones docentes

## Cambios
- La creación de docentes se ejecuta en una función API de Vercel con Firebase Admin SDK.
- La función valida el token Firebase y restringe la operación al UID administrador configurado en el proyecto.
- Se registra perfil, membresía, índice institucional, invitación y auditoría en Realtime Database.
- Resend envía un correo con dos pasos: confirmar correo y establecer contraseña.
- La creación de estudiantes conserva el flujo anterior.
- Diagnóstico sin secretos: `GET /api/health`.

## Variables de entorno de Vercel (Production)
`FIREBASE_PROJECT_ID`, `FIREBASE_CLIENT_EMAIL`, `FIREBASE_PRIVATE_KEY`, `FIREBASE_DATABASE_URL`, `RESEND_API_KEY`. Opcional: `RESEND_FROM_EMAIL` (remitente de dominio verificado). No incluyas estos valores en el repositorio ni en el ZIP.

## Despliegue
Sube el contenido de este ZIP al proyecto conectado a Vercel y despliega. Vercel instalará las dependencias de `package.json`. Comprueba `/api/health`; debe indicar `firebase: true` y `resend: true`.

## Requisitos externos pendientes
1. En Firebase Authentication → Settings → Authorized domains, confirma que `ethykos-next.vercel.app` esté autorizado. En Authentication → Templates, configura el enlace de acción personalizado para que apunte a `https://ethykos-next.vercel.app/auth-action` si deseas utilizar la pantalla personalizada incluida. Si no configuras el handler personalizado, Firebase utilizará su página de acción predeterminada.
2. Resend en modo de prueba suele restringir destinatarios al correo propietario de la cuenta. Para enviar invitaciones a docentes reales, verifica un dominio propio en Resend y configura `RESEND_FROM_EMAIL` con ese dominio. `ethykos-next.vercel.app` no es un dominio propio para autenticar correo.
3. Prueba primero con un destinatario permitido por Resend.

## Seguridad y alcance
- No se incluyen secretos ni archivos de cuenta de servicio.
- El UID administrador está fijado en backend y debe coincidir con la cuenta autorizada del proyecto.
- El correo puede fallar después de crear la cuenta; en ese caso la API informa que la cuenta quedó creada y el estado de invitación permanece pendiente para recuperación manual.
- Esta entrega no modifica reglas de Realtime Database.
- La comprobación de este paquete es estática; no se ha probado contra el Firebase/Resend reales ni desplegado en Vercel.


## V4.12.1 — prueba controlada de correo

Se agrega `POST /api/email/test`, protegido por Firebase ID token y UID administrador. Envía un mensaje de prueba fijo a `rrnewball@gmail.com` usando Resend. No crea cuentas ni escribe en Realtime Database. Desde el panel de administración, sección Docentes, el botón **Enviar correo de prueba a mi cuenta** ejecuta esta ruta.

La respuesta `sent: true` significa que Resend aceptó la solicitud; no garantiza por sí sola que el mensaje haya llegado a la bandeja. Revisar Recibidos, Spam y el panel Logs de Resend. El remitente predeterminado sigue siendo `onboarding@resend.dev`; el destinatario de prueba está fijado deliberadamente al correo propietario indicado.

## V4.12.2 — identidad visual de correos
- Se centralizan las plantillas HTML en `api/_lib/emailTemplates.js`.
- La invitación docente adopta el diseño institucional aprobado: encabezado azul Éthykos Next, lema, bienvenida, datos de cuenta y panel de activación.
- Se mantienen dos acciones independientes y explícitas: confirmar el correo y establecer la contraseña. Esto corresponde al flujo real de Firebase y evita presentar como una sola acción dos enlaces distintos.
- El correo técnico de prueba reutiliza la misma identidad visual.
- Maquetación con tablas y estilos en línea para mejorar compatibilidad con Gmail y Outlook, además de adaptación a pantallas pequeñas.
- No cambia la lógica de creación de cuentas, autenticación ni membresías.


## V4.12.3 — Vista previa segura de invitación docente

- Se agrega el endpoint protegido `POST /api/email/invitation-preview`, exclusivo para el administrador global.
- El panel Docentes incorpora el botón «Enviar vista previa de invitación» dirigido al correo administrador `rrnewball@gmail.com`.
- La vista previa usa datos demostrativos y la misma plantilla institucional de invitación, con botones visuales no funcionales claramente identificados.
- Esta operación no crea usuarios, no genera enlaces de verificación/restablecimiento y no modifica Firebase Realtime Database ni Firebase Authentication.
- Se define `APP_URL` en el endpoint real de invitaciones para evitar una referencia no declarada al construir enlaces de acción.


## V4.12.4 — Auditoría: consistencia de invitaciones
- Evita dejar cuentas de Firebase Authentication huérfanas si falla la generación de enlaces o el registro inicial en Realtime Database.
- Registra el estado `email_failed` cuando Resend rechaza el envío después de crear correctamente la cuenta y la membresía.
- Distingue fallos antes y después de persistir los datos; no informa falsamente que una cuenta quedó creada cuando la escritura inicial falló.
- Valida caracteres no permitidos en el identificador de institución.

## V4.13.0 — Base de autorización y contexto institucional

- Se incorpora `api/_lib/accessControl.js` con validación de token, correo verificado, membresía activa, rol e institución activa.
- Se incorpora `GET /api/institutions/context`, que devuelve únicamente las instituciones activas asociadas al usuario autenticado.
- Se añade `MODELO-DATOS-Y-PERMISOS-V4.13.md` con el modelo académico propuesto, matriz de permisos y plan de migración.
- Se añaden pruebas unitarias para autenticación, verificación de correo, membresías, roles y filtrado de instituciones.
- No se modifican las reglas de Realtime Database ni se migran datos existentes. La activación de permisos académicos queda condicionada a pruebas con Firebase Emulator Suite.
